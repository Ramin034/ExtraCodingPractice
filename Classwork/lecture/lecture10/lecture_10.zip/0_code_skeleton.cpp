#include <iostream>
#include <iomanip> 
#include <string>
#include <cmath> 
using namespace std;

int main()
{

    return 0;
}