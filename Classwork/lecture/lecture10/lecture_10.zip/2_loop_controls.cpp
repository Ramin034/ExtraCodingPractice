#include <iostream>

using namespace std;


int main()
{
    // continue - skips the current iteration of the loop
    cout << "continue statement demo" << endl;
    
    
    // break - terminates the loop
    cout << "break statement demo" << endl;
    

    return 0;
}