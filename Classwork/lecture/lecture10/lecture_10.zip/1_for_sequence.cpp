#include <iostream>

using namespace std;
/*
    while(condition)
    {
        statements;
    }

*/

/*
    for (initialization; condition; update)
    { 
        statements; // also called loop body
    }

    OR

    initialization;
    while(condition)
    {
        statements;
        update;
    }

*/

int main()
{
    int num = 0;
    cout << "Enter a number: ";
    cin >> num;
    
    // print numbers from 0 -> num
    
    
    
    // print every other number from 0 -> num -- 0 2 4 6 8 
    // approach 1
    
    // approach 2
    
    
    return 0;
}