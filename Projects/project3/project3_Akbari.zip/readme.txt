------------------------

HOW TO COMPILE AND RUN

------------------------

Compile: g++ -std=c++17 phase1.cpp player.cpp planet.cpp shop.cpp
Run: ./a.out

------------------------

DEPENDENCIES

------------------------

Player.h planet.h and shop.h must be in the same directory as the cpp

files in order to compile.

------------------------

SUBMISSION INFORMATION

------------------------

CSCI1300 Spring 2022 Project 3

Author: Ramin Akbari

Recitation: 102 - Nikhith Sannidhi

Date: April 21, 2022

------------------------

ABOUT THIS PROJECT

------------------------

This project is developing an application to run a game with about saving 
The human race, which can be based on your decision to find whether a
Planet is habitable or not. They can be considered habitable based on 
Oxygen and other resources.
